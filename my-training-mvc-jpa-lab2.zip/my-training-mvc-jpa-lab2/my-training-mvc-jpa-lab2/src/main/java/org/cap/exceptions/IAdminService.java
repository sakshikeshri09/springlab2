package org.cap.exceptions;

public interface IAdminService {

	public boolean validate(String name,String password);
}
