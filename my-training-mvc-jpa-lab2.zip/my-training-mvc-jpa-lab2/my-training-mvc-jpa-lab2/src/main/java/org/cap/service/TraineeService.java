package org.cap.service;



import java.util.List;

import javax.transaction.Transactional;
import org.cap.dao.ITraineeDao;
import org.cap.entities.Trainee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class TraineeService implements ITraineeService {

	@Autowired
	 private ITraineeDao dao;
	
	public ITraineeDao getDao() {
		return dao;
	}

	public void setDao(ITraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public Trainee addTrainee(Trainee trainee) {
		
		return null;
	}

	@Override
	public Trainee deleteTrainee(int traineeId) {
		
		return dao.deleteTrainee(traineeId);
	}

	@Override
	public Trainee modifyTrainee(int traineeId, String traineeName, String traineeDomain, String traineeLocation) {
		return 		dao.modifyTrainee(traineeId, traineeName, traineeDomain, traineeLocation);
		
	}

	@Override
	public Trainee retrieveTrainee(int traineeId) {
		return 	dao.retrieveTrainee(traineeId);
		
	}

	@Override
	public List<Trainee> retrieveall() {
		
		List<Trainee> list=dao.retrieveall();
		return list;
	}

}
