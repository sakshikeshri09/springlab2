package org.cap.exceptions;

public interface IAdminDao {

	public boolean validate(String name,String password);
}
